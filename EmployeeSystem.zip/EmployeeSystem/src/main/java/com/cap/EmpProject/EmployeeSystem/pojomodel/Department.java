package com.cap.EmpProject.EmployeeSystem.pojomodel;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Department")
public class Department {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dept_ID;
	private String dept_Desc;

	public Department() {

	}

	public Department(int dept_ID, String dept_Desc) {
		super();
		this.dept_ID = dept_ID;
		this.dept_Desc = dept_Desc;

	}

	public int getDept_ID() {
		return dept_ID;
	}

	public void setDept_ID(int dept_ID) {
		this.dept_ID = dept_ID;
	}

	public String getDept_Desc() {
		return dept_Desc;
	}

	public void setDept_Desc(String dept_Desc) {
		this.dept_Desc = dept_Desc;
	}

}
