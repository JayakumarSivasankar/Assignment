package com.cap.EmpProject.EmployeeSystem.pojomodel;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
@Table(name="Employee_01")
public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int Emp_ID;
	String EmpName;
	int Salary;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Dept_ID")
	private Department department;
	
	public Employee()
	{		
	}

	public Employee(int emp_ID, String empName, int salary, Department department) {
		super();
		Emp_ID = emp_ID;
		EmpName = empName;
		Salary = salary;
		this.department = department;
	}

	public int getEmp_ID() {
		return Emp_ID;
	}

	public void setEmp_ID(int emp_ID) {
		Emp_ID = emp_ID;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	
}
