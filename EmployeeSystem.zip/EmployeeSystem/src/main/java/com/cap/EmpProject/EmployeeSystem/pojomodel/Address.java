package com.cap.EmpProject.EmployeeSystem.pojomodel;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int addrId;
	@Column(name="AddressDesc")
	private String AddressDesc;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="emp_Id")
	private Employee employee;

	
	public Address()
	{
		
	}
	public Address(int addrId, String addressDesc, Employee employee) {
		
		this.addrId = addrId;
		AddressDesc = addressDesc;
	
		this.employee = employee;
	}
	
	public int getAddrId() {
		return addrId;
	}

	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}

	public String getAddressDesc() {
		return AddressDesc;
	}

	public void setAddressDesc(String addressDesc) {
		AddressDesc = addressDesc;
	}



	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	

}
