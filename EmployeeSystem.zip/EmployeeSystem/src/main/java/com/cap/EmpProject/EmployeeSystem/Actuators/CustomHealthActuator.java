package com.cap.EmpProject.EmployeeSystem.Actuators;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import java.lang.Math;

@Component
public class CustomHealthActuator implements HealthIndicator{

	@Override
	public Health health() {
		Double d = Math.random();
		if(d>0.15)
		{
			return Health.up().build();
		}
		

		
		return Health.down().withDetail("Error", d).build();
	}

}
