package com.cap.EmpProject.EmployeeSystem.controller;

import com.cap.EmpProject.EmployeeSystem.service.EmployeeService;
import com.cap.EmpProject.EmployeeSystem.dao.AddressDao;
import com.cap.EmpProject.EmployeeSystem.pojomodel.Address;
import com.cap.EmpProject.EmployeeSystem.pojomodel.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/EmpApp")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private AddressDao addressDao;

	@GetMapping("/getAllEmpDetails")
	public ResponseEntity<List<Employee>> getAll() {

		List<Employee> emplist = employeeService.getEmpFullDetails();
		return new ResponseEntity<List<Employee>>(emplist, HttpStatus.OK);
	}

	@PostMapping("/SaveEmpDetail")
	public ResponseEntity<List<Employee>> saveEmp(@RequestBody Employee emp) {

		List<Employee> emplistUpdated = employeeService.saveEmp(emp);
		return new ResponseEntity<List<Employee>>(emplistUpdated, HttpStatus.OK);
	}
	
	@PostMapping("/SaveAddress")
	public ResponseEntity<Address> saveAde(@RequestBody Address Add) {

		 Address Addr = addressDao.save(Add);
		return new ResponseEntity<Address>(Addr, HttpStatus.OK);
	}

	@GetMapping("/getEmpById/{id}")
	public ResponseEntity<Employee> getByIds(@PathVariable int id) {

		Optional<Employee> empl = employeeService.getEmpByID(id);
		return new ResponseEntity<Employee>(empl.get(), HttpStatus.OK);
	}

	@GetMapping("/likeValue/{likeValue}")
	public ResponseEntity<List<Employee>> likeEmpList(@PathVariable String likeValue) {
		List<Employee> likeEmpList = employeeService.getEmpLike(likeValue);
		return new ResponseEntity<List<Employee>>(likeEmpList, HttpStatus.OK);
	}

	@GetMapping("/MaxSalary")
	public ResponseEntity<String> maxSalary() {
		int maxSalary = employeeService.getMaxEmpSal();

		return new ResponseEntity<String>("Maximum Salary" + maxSalary, HttpStatus.OK);

	}

	@GetMapping("/MinSalary")
	public ResponseEntity<String> MinSalary() {
		int minSalary = employeeService.getMinEmpSal();

		return new ResponseEntity<String>("Minimum Salary" + minSalary, HttpStatus.OK);

	}

	
	@GetMapping("/TotalSalary")
	public ResponseEntity<String> TotalSalary() {
		int totalSalary = employeeService.getTotalEmpSal();

		return new ResponseEntity<String>("Minimum Salary" + totalSalary, HttpStatus.OK);

	}
}