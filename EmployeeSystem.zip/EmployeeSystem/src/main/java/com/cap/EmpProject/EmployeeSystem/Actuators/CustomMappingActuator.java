package com.cap.EmpProject.EmployeeSystem.Actuators;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.env.EnvironmentEndpoint;
import org.springframework.boot.origin.Origin;
import org.springframework.boot.origin.OriginLookup;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;


@Component
@RestController
@RequestMapping(path="/actuator/Env")
public class CustomMappingActuator extends AbstractEnvironment {

	@GetMapping("/custom")
	@Override
	public String[] getDefaultProfiles() {
		String[] s = { "Custom", "Own implementation" };
		return s;
	}

}
