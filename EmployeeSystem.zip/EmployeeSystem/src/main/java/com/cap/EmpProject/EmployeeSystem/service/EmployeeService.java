package com.cap.EmpProject.EmployeeSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cap.EmpProject.EmployeeSystem.pojomodel.Employee;


public interface EmployeeService {
	
	public List<Employee> getEmpFullDetails();
	public List<Employee> saveEmp(Employee emp);
	public Optional<Employee> getEmpByID(int id);
	public List<Employee> getEmpLike(String s);
	public Integer getMaxEmpSal();
	public Integer getMinEmpSal();
	public Integer getTotalEmpSal();
	

}
