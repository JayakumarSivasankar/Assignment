package com.cap.EmpProject.EmployeeSystem.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.EmpProject.EmployeeSystem.dao.EmployeeDao;
import com.cap.EmpProject.EmployeeSystem.pojomodel.Employee;
import com.cap.EmpProject.EmployeeSystem.service.EmployeeService;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	EmployeeDao employeeDao;
	
	public List<Employee> getEmpFullDetails() {
		
	return employeeDao.findAll();

	}
	
	
	public List<Employee> saveEmp(Employee emp)
	{
		 employeeDao.save(emp);
		 return getEmpFullDetails();
	}

	public Optional<Employee> getEmpByID(int id){
		java.util.Optional<Employee> empl=employeeDao.findById(id);
		return empl;
	}
	public List<Employee> getEmpLike(String likeValue){
		List<Employee> likeStringEmpList=employeeDao.getEmpLike(likeValue);
		
		return likeStringEmpList; 

	}
	
	public Integer getMaxEmpSal()
	{
		return employeeDao.maxEmpSalary() ;
	}
	public Integer getMinEmpSal()
	{
		return employeeDao.minEmpSalary() ;
	}
	public Integer getTotalEmpSal()
	{
		return employeeDao.TotalEmpSalary() ;
	}
	

	
}
