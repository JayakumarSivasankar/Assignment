package com.cap.EmpProject.EmployeeSystem.dao;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cap.EmpProject.EmployeeSystem.pojomodel.Employee;
import java.util.List;
import org.springframework.data.jpa.repository.Query;


@Repository("EmployeeDao")
public interface EmployeeDao extends  JpaRepository<Employee, Integer> {

	
	@Query(value="select * from Employee_01 e where e.emp_name LIKE ?1%",nativeQuery = true)
	public List<Employee> getEmpLike(String likeString);
	
	@Query(value="select sum(e.salary) from Employee_01 e",nativeQuery = true)
	public Integer TotalEmpSalary();
	
	@Query(value="select min(e.salary) from Employee_01 e",nativeQuery = true)
	public Integer minEmpSalary();
	
	@Query(value="select max(e.salary) from Employee_01 e",nativeQuery = true)
	public Integer maxEmpSalary();


}
