package com.cap.demo.service;

import java.util.List;
import java.util.Optional;

import com.cap.demo.model.Employee;



public interface IEmployeeService {
	
	public List<Employee> getAllEmp();
	public Optional<Employee> getEmpByID(int id);
	public List<Employee> getEmpLike(String s);
	public Integer getMaxEmpSal();
	public Integer getMinEmpSal();
	public Integer getTotalEmpSal();

}
