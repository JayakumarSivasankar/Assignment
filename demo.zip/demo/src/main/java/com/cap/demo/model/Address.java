package com.cap.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Address")
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Addr_ID")
	private int addrId;
	@Column(name="address_desc")
	private String addrDesc;
	/*
	 * @Column(name="Emp_ID") private int empID;
	 */
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="emp_id",referencedColumnName = "emp_id")
	private Employee employee;
	
	
	public Address()
	{
		
	}


	public Address(int addrId, String addrDesc, Employee employee) {
		super();
		this.addrId = addrId;
		this.addrDesc = addrDesc;
		this.employee = employee;
	}


	public int getAddrId() {
		return addrId;
	}


	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}


	public String getAddrDesc() {
		return addrDesc;
	}


	public void setAddrDesc(String addrDesc) {
		this.addrDesc = addrDesc;
	}


	public Employee getEmployee() {
		return employee;
	}


	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
		
	

}
