package com.cap.demo.model;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;


@Entity
@Table(name="Department")
public class Department {
	
	@Id
	@Column(name="dept_id")
	private int DeptId; 
	
	@Column(name="dept_Desc")
	private String description;
	
	
	public Department()
	{
		
	}
	
	public Department(int deptId, String description) {
		super();
		DeptId = deptId;
		this.description = description;
	}

	public int getDeptId() {
		return DeptId;
	}

	public void setDeptId(int deptId) {
		DeptId = deptId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	

}
