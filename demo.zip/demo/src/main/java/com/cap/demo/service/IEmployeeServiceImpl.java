package com.cap.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.demo.dao.EmployeeRepo;
import com.cap.demo.model.Employee;

@Service("iEmployeeService")
public class IEmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	EmployeeRepo empRepo;

	public List<Employee> getAllEmp()
	{
		
		return empRepo.findAll();
	}
	
	public Optional<Employee> getEmpByID(int id){
		java.util.Optional<Employee> empl=empRepo.findById(id);
		return empl;
	}
	public List<Employee> getEmpLike(String likeValue){
		List<Employee> likeStringEmpList=empRepo.getEmpLike(likeValue);
		
		return likeStringEmpList; 

	}
	
	public Integer getMaxEmpSal()
	{
		return empRepo.maxEmpSalary() ;
	}
	public Integer getMinEmpSal()
	{
		return empRepo.minEmpSalary() ;
	}
	public Integer getTotalEmpSal()
	{
		return empRepo.TotalEmpSalary() ;
	}
	
	
}
