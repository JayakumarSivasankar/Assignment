package com.cap.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
@Table(name = "employee_01")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "emp_id")
	private int ID;

	@Column(name = "Emp_name")
	private String EmpName;

	@Column(name = "Salary")
	private int EmpSal;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "dept_id", referencedColumnName = "dept_id")
	private Department department;

	/*
	 * @OneToMany(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="emp_Id",referencedColumnName = "emp_Id") private
	 * List<Address> address;
	 */

	public Employee() {

	}

	public Employee(int iD, String empName, int empSal, Department department) {
		super();
		ID = iD;
		EmpName = empName;
		EmpSal = empSal;
		this.department = department;

	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public int getEmpSal() {
		return EmpSal;
	}

	public void setEmpSal(int empSal) {
		EmpSal = empSal;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

}
