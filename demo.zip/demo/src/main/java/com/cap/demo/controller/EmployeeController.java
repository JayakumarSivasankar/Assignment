package com.cap.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cap.demo.dao.AddressRepo;
import com.cap.demo.model.Address;
import com.cap.demo.model.Employee;
import com.cap.demo.service.IEmployeeService;



@RestController
@RequestMapping(path="/employeeApp")
public class EmployeeController {
	
	@Autowired
	IEmployeeService empservice;
	
	@Autowired
	AddressRepo addressRepo;

	@GetMapping("/getAllEmp")
	public ResponseEntity<List<Employee>> getAllEmp() {

		List<Employee> emplist = empservice.getAllEmp();
		return new ResponseEntity<List<Employee>>(emplist, HttpStatus.OK);
	}
	
	@GetMapping("/getAllAddr")
	public ResponseEntity<List<Address>> getAllAddr() {

		List<Address> AddrList = addressRepo.findAll();
		return new ResponseEntity<List<Address>>(AddrList, HttpStatus.OK);
	}
	
	@GetMapping("/getEmpById/{id}")
	public ResponseEntity<Employee> getByIds(@PathVariable int id) {

		Optional<Employee> empl = empservice.getEmpByID(id);
		return new ResponseEntity<Employee>(empl.get(), HttpStatus.OK);
	}

	@GetMapping("/likeValue/{likeValue}")
	public ResponseEntity<List<Employee>> likeEmpList(@PathVariable String likeValue) {
		List<Employee> likeEmpList = empservice.getEmpLike(likeValue);
		return new ResponseEntity<List<Employee>>(likeEmpList, HttpStatus.OK);
	}

	@GetMapping("/MaxSalary")
	public ResponseEntity<String> maxSalary() {
		int maxSalary = empservice.getMaxEmpSal();

		return new ResponseEntity<String>("Maximum Salary" + maxSalary, HttpStatus.OK);

	}

	@GetMapping("/MinSalary")
	public ResponseEntity<String> MinSalary() {
		int minSalary = empservice.getMinEmpSal();

		return new ResponseEntity<String>("Minimum Salary" + minSalary, HttpStatus.OK);

	}

	
	@GetMapping("/TotalSalary")
	public ResponseEntity<String> TotalSalary() {
		int totalSalary = empservice.getTotalEmpSal();

		return new ResponseEntity<String>("Total Salary" + totalSalary, HttpStatus.OK);

	}
	
	
	
	
	
}
